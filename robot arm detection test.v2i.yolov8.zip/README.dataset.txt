# robot arm detection test > 2024-10-12 11:51pm
https://universe.roboflow.com/origami-robot/robot-arm-detection-test

Provided by a Roboflow user
License: CC BY 4.0

